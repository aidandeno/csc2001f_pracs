// Hussein's Test Binary Search
// 22 March 2017
// Hussein Suleman

import java.util.Random;

public class BinarySearch
{
   int n;
   int data [];
   int num;

   public BinarySearch ( int n )
   {
      this.n = n;
      data = new int[n];
      num = 0;
   }
   
   public void insert ( int value )
   {
      data[num++] = value;
   }
   
   public void selectionSort ()
   {
      for ( int i=0; i<(num-1); i++ )
      {
         int min = i;
         for ( int j=i+1; j<num; j++ )
            if (data[j] < data[min])
               min = j;
         int temp = data[i];
         data[i] = data[min];
         data[min] = temp;      
      }
   }
   
   public void traverse ()
   {
      for ( int i=0; i<num; i++ )
         System.out.print (data[i]+" ");
      System.out.println ();
   }
   
   public int binarySearch ( int value )
   {
      int left = 0;
      int right = num-1;
      while (left <= right)
      {
         int mid = (left + right) / 2;
         if (data[mid] == value)
            return mid;
         else if (data[mid] < value)
            left = mid+1;
         else
            right = mid-1;
      }
      return -1;
   }

   public static void main ( String [] args )
   {
      int n = 200;
      int max = 1000;
   
      BinarySearch bs = new BinarySearch (n);
      Random ran = new Random ();
      
      for ( int i=0; i<n; i++ )
         bs.insert (ran.nextInt (max));      
      
      bs.selectionSort ();
      bs.traverse ();
      
      for ( int i=0; i<50; i++ )
      {
         int r = ran.nextInt (max);
         System.out.println (r+" : "+bs.binarySearch (r));
      }
   }
}
